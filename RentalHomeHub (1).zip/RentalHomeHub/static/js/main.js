// Main JavaScript file for RentHome application

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    var alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Property image upload preview
    var imageInput = document.getElementById('image');
    if (imageInput) {
        imageInput.addEventListener('change', function(e) {
            var file = e.target.files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var preview = document.getElementById('image-preview');
                    if (!preview) {
                        preview = document.createElement('img');
                        preview.id = 'image-preview';
                        preview.className = 'img-thumbnail mt-2';
                        preview.style.width = '200px';
                        preview.style.height = '150px';
                        preview.style.objectFit = 'cover';
                        imageInput.parentNode.appendChild(preview);
                    }
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // Search form validation
    var searchForm = document.querySelector('form[action*="browse_properties"]');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            var minPrice = document.getElementById('min_price');
            var maxPrice = document.getElementById('max_price');
            
            if (minPrice && maxPrice && minPrice.value && maxPrice.value) {
                if (parseFloat(minPrice.value) > parseFloat(maxPrice.value)) {
                    e.preventDefault();
                    alert('Minimum price cannot be greater than maximum price.');
                    return false;
                }
            }
        });
    }

    // Booking form date validation
    var bookingForm = document.querySelector('form[action*="book_property"]');
    if (bookingForm) {
        var checkInInput = document.getElementById('check_in');
        var checkOutInput = document.getElementById('check_out');
        
        if (checkInInput && checkOutInput) {
            // Set minimum date to today
            var today = new Date().toISOString().split('T')[0];
            checkInInput.min = today;
            
            checkInInput.addEventListener('change', function() {
                var checkInDate = new Date(this.value);
                var minCheckOut = new Date(checkInDate);
                minCheckOut.setDate(minCheckOut.getDate() + 1);
                
                checkOutInput.min = minCheckOut.toISOString().split('T')[0];
                
                // Reset check-out if it's invalid
                if (checkOutInput.value && new Date(checkOutInput.value) <= checkInDate) {
                    checkOutInput.value = '';
                }
            });
            
            // Calculate total price dynamically
            function calculateTotal() {
                var checkIn = checkInInput.value;
                var checkOut = checkOutInput.value;
                var pricePerNight = parseFloat(document.querySelector('.text-primary').textContent.replace('$', ''));
                
                if (checkIn && checkOut) {
                    var startDate = new Date(checkIn);
                    var endDate = new Date(checkOut);
                    var nights = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
                    
                    if (nights > 0) {
                        var total = nights * pricePerNight;
                        var totalElement = document.getElementById('total-price');
                        if (!totalElement) {
                            totalElement = document.createElement('div');
                            totalElement.id = 'total-price';
                            totalElement.className = 'mt-2 text-muted';
                            checkOutInput.parentNode.appendChild(totalElement);
                        }
                        totalElement.innerHTML = `<small>Total: $${total.toFixed(2)} (${nights} night${nights > 1 ? 's' : ''})</small>`;
                    }
                }
            }
            
            checkInInput.addEventListener('change', calculateTotal);
            checkOutInput.addEventListener('change', calculateTotal);
        }
    }

    // Confirmation dialogs for delete actions
    var deleteButtons = document.querySelectorAll('form[action*="delete"] button[type="submit"]');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
                return false;
            }
        });
    });

    // Auto-expand textareas
    var textareas = document.querySelectorAll('textarea');
    textareas.forEach(function(textarea) {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    });

    // Smooth scrolling for anchor links
    var anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            var href = this.getAttribute('href');
            if (href === '#') return; // Skip empty anchors
            e.preventDefault();
            var target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Add loading state to forms
    var forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            var submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
            }
        });
    });

    // Property type filter enhancement
    var propertyTypeSelect = document.getElementById('property_type');
    if (propertyTypeSelect) {
        propertyTypeSelect.addEventListener('change', function() {
            // Add icon based on property type
            var icon = '';
            switch(this.value) {
                case 'house':
                    icon = 'fas fa-home';
                    break;
                case 'apartment':
                    icon = 'fas fa-building';
                    break;
                case 'condo':
                    icon = 'fas fa-city';
                    break;
                case 'villa':
                    icon = 'fas fa-tree';
                    break;
                case 'cabin':
                    icon = 'fas fa-mountain';
                    break;
                default:
                    icon = 'fas fa-home';
            }
            
            // Update any visual indicators if needed
            var typeIndicator = document.getElementById('type-indicator');
            if (typeIndicator) {
                typeIndicator.className = icon;
            }
        });
    }

    // Initialize fade-in animations
    var fadeElements = document.querySelectorAll('.fade-in');
    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    });
    
    fadeElements.forEach(function(element) {
        observer.observe(element);
    });

    // Mobile menu improvements
    var navbarToggler = document.querySelector('.navbar-toggler');
    if (navbarToggler) {
        navbarToggler.addEventListener('click', function() {
            var navbar = document.querySelector('.navbar-collapse');
            if (navbar) {
                navbar.classList.toggle('show');
            }
        });
    }

    // Price formatting
    var priceInputs = document.querySelectorAll('input[name*="price"]');
    priceInputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            var value = parseFloat(this.value);
            if (!isNaN(value)) {
                this.value = value.toFixed(2);
            }
        });
    });
});

// Utility functions
function showAlert(message, type = 'info') {
    var alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    var container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            var bsAlert = new bootstrap.Alert(alertDiv);
            bsAlert.close();
        }, 5000);
    }
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(dateString) {
    var date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Export functions for use in other scripts
window.RentHome = {
    showAlert: showAlert,
    formatCurrency: formatCurrency,
    formatDate: formatDate
};
