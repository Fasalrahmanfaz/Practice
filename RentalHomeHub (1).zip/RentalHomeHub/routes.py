import os
import json
from datetime import datetime, date
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import current_user
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage

from app import app, db
from models import Property, Booking, Inquiry
from replit_auth import require_login, make_replit_blueprint
from admin_auth import admin_required, verify_admin_credentials, is_admin

# Register the authentication blueprint
app.register_blueprint(make_replit_blueprint(), url_prefix="/auth")

# Make session permanent
@app.before_request
def make_session_permanent():
    session.permanent = True

# File upload helper
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_uploaded_file(file):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Add timestamp to avoid filename conflicts
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
        filename = timestamp + filename
        
        # Create upload directory if it doesn't exist
        upload_dir = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'])
        os.makedirs(upload_dir, exist_ok=True)
        
        file_path = os.path.join(upload_dir, filename)
        file.save(file_path)
        return filename
    return None

@app.route('/')
def index():
    # Get featured properties (latest 6)
    featured_properties = Property.query.filter_by(is_available=True).order_by(Property.created_at.desc()).limit(6).all()
    
    # Get search parameters
    location = request.args.get('location', '')
    property_type = request.args.get('property_type', '')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    
    # Filter properties if search parameters are provided
    if location or property_type or min_price is not None or max_price is not None:
        return redirect(url_for('browse_properties', 
                               location=location, 
                               property_type=property_type,
                               min_price=min_price,
                               max_price=max_price))
    
    return render_template('index.html', featured_properties=featured_properties)

@app.route('/properties')
def browse_properties():
    # Get filter parameters
    location = request.args.get('location', '')
    property_type = request.args.get('property_type', '')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    
    # Build query
    query = Property.query.filter_by(is_available=True)
    
    if location:
        query = query.filter(Property.location.ilike(f'%{location}%'))
    
    if property_type:
        query = query.filter(Property.property_type == property_type)
    
    if min_price is not None:
        query = query.filter(Property.price_per_night >= min_price)
    
    if max_price is not None:
        query = query.filter(Property.price_per_night <= max_price)
    
    properties = query.order_by(Property.created_at.desc()).all()
    
    # Get unique property types for filter dropdown
    property_types = db.session.query(Property.property_type).distinct().all()
    property_types = [pt[0] for pt in property_types]
    
    return render_template('properties.html', 
                         properties=properties,
                         property_types=property_types,
                         filters={
                             'location': location,
                             'property_type': property_type,
                             'min_price': min_price,
                             'max_price': max_price
                         })

@app.route('/property/<int:property_id>')
def property_detail(property_id):
    property = Property.query.get_or_404(property_id)
    
    # Parse amenities from JSON string
    amenities = []
    if property.amenities:
        try:
            amenities = json.loads(property.amenities)
        except:
            amenities = []
    
    return render_template('property_detail.html', property=property, amenities=amenities)

@app.route('/book/<int:property_id>', methods=['GET', 'POST'])
@require_login
def book_property(property_id):
    property = Property.query.get_or_404(property_id)
    
    if request.method == 'POST':
        check_in_str = request.form.get('check_in')
        check_out_str = request.form.get('check_out')
        guests = request.form.get('guests', type=int)
        message = request.form.get('message', '')
        
        # Validate dates
        try:
            check_in = datetime.strptime(check_in_str, '%Y-%m-%d').date()
            check_out = datetime.strptime(check_out_str, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format. Please use the date picker.', 'error')
            return redirect(url_for('property_detail', property_id=property_id))
        
        # Validate booking data
        if check_in >= check_out:
            flash('Check-out date must be after check-in date.', 'error')
            return redirect(url_for('property_detail', property_id=property_id))
        
        if check_in < date.today():
            flash('Check-in date cannot be in the past.', 'error')
            return redirect(url_for('property_detail', property_id=property_id))
        
        if guests > property.max_guests:
            flash(f'Maximum number of guests for this property is {property.max_guests}.', 'error')
            return redirect(url_for('property_detail', property_id=property_id))
        
        # Check for overlapping bookings
        overlapping_bookings = Booking.query.filter(
            Booking.property_id == property_id,
            Booking.status.in_(['pending', 'confirmed']),
            Booking.check_in_date < check_out,
            Booking.check_out_date > check_in
        ).count()
        
        if overlapping_bookings > 0:
            flash('This property is not available for the selected dates.', 'error')
            return redirect(url_for('property_detail', property_id=property_id))
        
        # Calculate total price
        nights = (check_out - check_in).days
        total_price = nights * property.price_per_night
        
        # Create booking
        booking = Booking(
            property_id=property_id,
            tenant_id=current_user.id,
            check_in_date=check_in,
            check_out_date=check_out,
            total_guests=guests,
            total_price=total_price,
            message=message
        )
        
        db.session.add(booking)
        db.session.commit()
        
        flash('Booking request submitted successfully! The property owner will review your request.', 'success')
        return redirect(url_for('my_bookings'))
    
    return redirect(url_for('property_detail', property_id=property_id))

@app.route('/dashboard')
@require_login
def dashboard():
    # Get user's properties
    properties = Property.query.filter_by(owner_id=current_user.id).order_by(Property.created_at.desc()).all()
    
    # Get bookings for user's properties
    property_ids = [p.id for p in properties]
    bookings = Booking.query.filter(Booking.property_id.in_(property_ids)).order_by(Booking.created_at.desc()).all() if property_ids else []
    
    # Get inquiries for user's properties
    inquiries = Inquiry.query.filter(Inquiry.property_id.in_(property_ids)).order_by(Inquiry.created_at.desc()).all() if property_ids else []
    
    return render_template('dashboard.html', 
                         properties=properties, 
                         bookings=bookings, 
                         inquiries=inquiries)

@app.route('/add-property', methods=['GET', 'POST'])
@require_login
def add_property():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        location = request.form.get('location')
        price_per_night = request.form.get('price_per_night', type=float)
        property_type = request.form.get('property_type')
        bedrooms = request.form.get('bedrooms', type=int)
        bathrooms = request.form.get('bathrooms', type=int)
        max_guests = request.form.get('max_guests', type=int)
        
        # Handle amenities
        amenities_list = request.form.getlist('amenities')
        amenities_json = json.dumps(amenities_list)
        
        # Handle file upload
        image_filename = None
        if 'image' in request.files:
            file = request.files['image']
            if file.filename:
                image_filename = save_uploaded_file(file)
                if not image_filename:
                    flash('Invalid image file. Please upload a valid image.', 'error')
                    return render_template('add_property.html')
        
        # Create property
        property = Property(
            title=title,
            description=description,
            location=location,
            price_per_night=price_per_night,
            property_type=property_type,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            max_guests=max_guests,
            amenities=amenities_json,
            image_filename=image_filename,
            owner_id=current_user.id
        )
        
        db.session.add(property)
        db.session.commit()
        
        flash('Property added successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('add_property.html')

@app.route('/edit-property/<int:property_id>', methods=['GET', 'POST'])
@require_login
def edit_property(property_id):
    property = Property.query.get_or_404(property_id)
    
    # Check if user owns this property
    if property.owner_id != current_user.id:
        flash('You do not have permission to edit this property.', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        property.title = request.form.get('title')
        property.description = request.form.get('description')
        property.location = request.form.get('location')
        property.price_per_night = request.form.get('price_per_night', type=float)
        property.property_type = request.form.get('property_type')
        property.bedrooms = request.form.get('bedrooms', type=int)
        property.bathrooms = request.form.get('bathrooms', type=int)
        property.max_guests = request.form.get('max_guests', type=int)
        property.is_available = request.form.get('is_available') == 'on'
        
        # Handle amenities
        amenities_list = request.form.getlist('amenities')
        property.amenities = json.dumps(amenities_list)
        
        # Handle file upload
        if 'image' in request.files:
            file = request.files['image']
            if file.filename:
                image_filename = save_uploaded_file(file)
                if image_filename:
                    property.image_filename = image_filename
                else:
                    flash('Invalid image file. Please upload a valid image.', 'error')
                    return render_template('add_property.html', property=property, editing=True)
        
        property.updated_at = datetime.now()
        db.session.commit()
        
        flash('Property updated successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    # Parse amenities for form
    amenities = []
    if property.amenities:
        try:
            amenities = json.loads(property.amenities)
        except:
            amenities = []
    
    return render_template('add_property.html', property=property, amenities=amenities, editing=True)

@app.route('/delete-property/<int:property_id>', methods=['POST'])
@require_login
def delete_property(property_id):
    property = Property.query.get_or_404(property_id)
    
    # Check if user owns this property
    if property.owner_id != current_user.id:
        flash('You do not have permission to delete this property.', 'error')
        return redirect(url_for('dashboard'))
    
    db.session.delete(property)
    db.session.commit()
    
    flash('Property deleted successfully!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/my-bookings')
@require_login
def my_bookings():
    bookings = Booking.query.filter_by(tenant_id=current_user.id).order_by(Booking.created_at.desc()).all()
    return render_template('bookings.html', bookings=bookings)

@app.route('/booking/<int:booking_id>/cancel', methods=['POST'])
@require_login
def cancel_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    
    # Check if user owns this booking
    if booking.tenant_id != current_user.id:
        flash('You do not have permission to cancel this booking.', 'error')
        return redirect(url_for('my_bookings'))
    
    if booking.status == 'cancelled':
        flash('This booking is already cancelled.', 'error')
        return redirect(url_for('my_bookings'))
    
    booking.status = 'cancelled'
    db.session.commit()
    
    flash('Booking cancelled successfully!', 'success')
    return redirect(url_for('my_bookings'))

@app.route('/booking/<int:booking_id>/update-status', methods=['POST'])
@require_login
def update_booking_status(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    
    # Check if user owns the property
    if booking.property.owner_id != current_user.id:
        flash('You do not have permission to update this booking.', 'error')
        return redirect(url_for('dashboard'))
    
    new_status = request.form.get('status')
    if new_status in ['confirmed', 'cancelled']:
        booking.status = new_status
        db.session.commit()
        flash(f'Booking {new_status} successfully!', 'success')
    else:
        flash('Invalid status.', 'error')
    
    return redirect(url_for('dashboard'))

@app.route('/contact/<int:property_id>', methods=['POST'])
@require_login
def contact_owner(property_id):
    property = Property.query.get_or_404(property_id)
    
    subject = request.form.get('subject')
    message = request.form.get('message')
    contact_email = request.form.get('contact_email')
    
    inquiry = Inquiry(
        property_id=property_id,
        sender_id=current_user.id,
        subject=subject,
        message=message,
        contact_email=contact_email
    )
    
    db.session.add(inquiry)
    db.session.commit()
    
    flash('Your inquiry has been sent to the property owner!', 'success')
    return redirect(url_for('property_detail', property_id=property_id))

# Admin Routes
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if verify_admin_credentials(username, password):
            session['admin_logged_in'] = True
            session['admin_username'] = username
            flash('Admin login successful!', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid admin credentials.', 'error')
    
    return render_template('admin_login.html')

@app.route('/admin/logout')
@admin_required
def admin_logout():
    session.pop('admin_logged_in', None)
    session.pop('admin_username', None)
    flash('Admin logged out successfully.', 'success')
    return redirect(url_for('index'))

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    # Get all properties, bookings, and users
    properties = Property.query.order_by(Property.created_at.desc()).all()
    bookings = Booking.query.order_by(Booking.created_at.desc()).all()
    
    # Get statistics
    total_properties = Property.query.count()
    total_bookings = Booking.query.count()
    confirmed_bookings = Booking.query.filter_by(status='confirmed').count()
    pending_bookings = Booking.query.filter_by(status='pending').count()
    
    # Calculate total revenue from confirmed bookings
    total_revenue = db.session.query(db.func.sum(Booking.total_price)).filter_by(status='confirmed').scalar() or 0
    
    return render_template('admin_dashboard.html', 
                         properties=properties, 
                         bookings=bookings,
                         stats={
                             'total_properties': total_properties,
                             'total_bookings': total_bookings,
                             'confirmed_bookings': confirmed_bookings,
                             'pending_bookings': pending_bookings,
                             'total_revenue': total_revenue
                         })

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
