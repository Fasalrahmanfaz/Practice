# Rental Home System

## Overview

This is a Flask-based rental home system that allows property owners to list their properties and tenants to browse and book accommodations. The application features user authentication via Replit Auth, property management, booking functionality, and inquiry handling.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Flask with SQLAlchemy ORM
- **Authentication**: Replit Auth integration using Flask-Dance OAuth
- **Database**: SQLite (configured via DATABASE_URL environment variable)
- **Session Management**: Flask sessions with permanent sessions enabled
- **File Uploads**: Werkzeug secure file handling for property images

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Bootstrap 5 styling
- **CSS Framework**: Bootstrap Agent Dark Theme from Replit CDN
- **Icons**: Font Awesome 6.0.0
- **JavaScript**: Vanilla JavaScript with Bootstrap components
- **Responsive Design**: Mobile-first approach with Bootstrap grid system

### Data Storage
- **Primary Database**: SQLite with SQLAlchemy ORM
- **File Storage**: Local filesystem for uploaded property images
- **Session Storage**: Server-side session management

## Key Components

### User Management
- **User Model**: Stores user profile information (required for Replit Auth)
- **OAuth Model**: Handles OAuth token storage (required for Replit Auth)
- **Login Manager**: Flask-Login integration for session management
- **Custom Storage**: UserSessionStorage class for OAuth token persistence

### Property Management
- **Property Model**: Stores property details including title, description, location, pricing
- **Image Upload**: Secure file upload with size limits (16MB max)
- **Property CRUD**: Full create, read, update, delete operations

### Booking System
- **Booking Model**: Manages rental bookings with date validation
- **Status Tracking**: Booking status management (pending, confirmed, cancelled)
- **Tenant Relations**: Links bookings to users via foreign keys

### Inquiry System
- **Inquiry Model**: Handles property inquiries and communication
- **Owner Notifications**: System for notifying property owners of inquiries

## Data Flow

1. **User Authentication**: Users authenticate via Replit Auth OAuth flow
2. **Property Listing**: Authenticated users can create and manage property listings
3. **Property Discovery**: All users can browse properties with filtering capabilities
4. **Booking Process**: Authenticated users can book properties with date validation
5. **Inquiry Handling**: Users can send inquiries to property owners
6. **File Management**: Property images are uploaded and stored securely

## External Dependencies

### Required Services
- **Replit Auth**: OAuth authentication service integration
- **Database**: Configured via DATABASE_URL environment variable
- **Session Secret**: Required for secure session management

### CDN Resources
- Bootstrap Agent Dark Theme (from Replit CDN)
- Font Awesome icons
- Bootstrap JavaScript components

### Python Packages
- Flask and Flask extensions (SQLAlchemy, Login, Dance)
- SQLAlchemy for ORM
- Werkzeug for utilities
- JWT for token handling
- OAuthLib for OAuth flow

## Deployment Strategy

### Environment Configuration
- **SESSION_SECRET**: Required environment variable for session security
- **DATABASE_URL**: Database connection string
- **Upload Directory**: Configured for static/uploads with proper permissions

### Application Structure
- **Entry Point**: main.py runs the Flask application
- **App Factory**: app.py initializes Flask app and database
- **Route Organization**: routes.py contains all URL endpoints
- **Model Definitions**: models.py defines database schema
- **Authentication**: replit_auth.py handles OAuth integration

### File Upload Configuration
- Maximum file size: 16MB
- Allowed formats: PNG, JPG, JPEG, GIF, WEBP
- Timestamped filenames to prevent conflicts
- Automatic directory creation for uploads

### Database Management
- Automatic table creation on startup
- Connection pooling with pre-ping and recycle settings
- Cascade delete relationships for data integrity

The application follows a traditional MVC pattern with clear separation of concerns, making it maintainable and extensible for future enhancements.