import os
from functools import wraps
from flask import session, request, redirect, url_for, render_template, flash

def load_admin_credentials():
    """Load admin credentials from the admin file"""
    try:
        with open('admin', 'r') as f:
            lines = f.read().strip().split('\n')
            if len(lines) >= 2:
                return lines[0], lines[1]
    except FileNotFoundError:
        pass
    return None, None

def verify_admin_credentials(username, password):
    """Verify admin credentials"""
    admin_username, admin_password = load_admin_credentials()
    return username == admin_username and password == admin_password

def admin_required(f):
    """Decorator to require admin authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

def is_admin():
    """Check if current user is admin"""
    return session.get('admin_logged_in', False)